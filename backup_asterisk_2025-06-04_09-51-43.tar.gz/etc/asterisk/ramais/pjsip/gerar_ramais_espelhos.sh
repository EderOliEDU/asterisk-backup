#!/bin/bash

PJSIP_CONF="/etc/asterisk/pjsip.conf"
RAMAIS_DIR="/etc/asterisk/ramais"
ESPELHO_DIR="$RAMAIS_DIR/espelhos"

mkdir -p "$RAMAIS_DIR"
mkdir -p "$ESPELHO_DIR"

echo "Iniciando varredura de includes no $PJSIP_CONF..."
echo "-----------------------------------------------"

# Função para gerar ramal
gerar_ramal() {
  local RAMAL="$1"
  local ARQUIVO="$RAMAIS_DIR/ramal${RAMAL}.conf"

  if [ ! -f "$ARQUIVO" ]; then
    echo "Gerando arquivo de ramal: $ARQUIVO"
    cat <<EOF > "$ARQUIVO"
; ======================================
; Configuracao do Ramal e Tronco - $RAMAL
; ======================================

[$RAMAL]
type=endpoint
transport=transport-tls
context=chamadas-realizadas
disallow=all
allow=g722,ulaw,alaw
auth=auth$RAMAL
aors=$RAMAL
direct_media=no

[auth$RAMAL]
type=auth
auth_type=userpass
username=$RAMAL
password=senha$RAMAL

[$RAMAL]
type=aor
max_contacts=1

; ======================================
; Tronco vinculado ao Ramal $RAMAL (Oi)
; ======================================

[oi-$RAMAL]
type=endpoint
transport=transport-tls
aors=oi-$RAMAL-aor
context=entrada-oi
disallow=all
allow=alaw,ulaw
force_rport=yes
outbound_auth=oi-$RAMAL-auth
outbound_proxy=sip:200.97.69.122:5061
from_domain=200.97.69.122
from_user=6634100$(printf "%03d" $RAMAL)
trust_id_inbound=yes
trust_id_outbound=yes
send_pai=yes
send_rpid=yes
sdp_session=pjmedia

[oi-$RAMAL-aor]
type=aor
contact=sip:6634100$(printf "%03d" $RAMAL)@200.97.69.122:5061
max_contacts=1
qualify_frequency=15

[oi-$RAMAL-auth]
type=auth
auth_type=userpass
username=6634100$(printf "%03d" $RAMAL)
password=SENHA_DO_NUMERO_AQUI

[oi-$RAMAL-identify]
type=identify
endpoint=oi-$RAMAL
match=200.97.69.122
EOF
  else
    echo "Arquivo de ramal $ARQUIVO já existe. Ignorando."
  fi
}

# Função para gerar espelhos
gerar_espelhos() {
  local BASE="$1"
  local ARQUIVO="$ESPELHO_DIR/espelhos${BASE}.conf"

  if [ ! -f "$ARQUIVO" ]; then
    echo "Arquivo de espelhos $ARQUIVO não encontrado."
    echo -n "Quantos espelhos deseja criar para o ramal $BASE? "
    read QTD

    echo "Criando espelhos no arquivo: $ARQUIVO"
    echo "; Ramais espelhos do ramal $BASE" > "$ARQUIVO"

    for i in $(seq 1 $QTD); do
      PREFIX="${i}${BASE}"
      cat <<EOF >> "$ARQUIVO"

[$PREFIX]
type=endpoint
context=chamadas-realizadas
disallow=all
allow=g722,ulaw,alaw
auth=auth$PREFIX
aors=$BASE
direct_media=no

[auth$PREFIX]
type=auth
auth_type=userpass
username=$PREFIX
password=senha$PREFIX

[$PREFIX]
type=aor
max_contacts=1
EOF
    done

    echo "Arquivo $ARQUIVO criado com $QTD espelhos."
  else
    echo "Arquivo de espelhos $ARQUIVO já existe. Ignorando."
  fi
}

# Processar includes de ramais
grep -oP '(?<=#include\\s)ramais/ramal\\d+\\.conf' "$PJSIP_CONF" | while read -r INCLUDE; do
  RAMAL=$(basename "$INCLUDE" .conf | grep -oP '\\d+')
  gerar_ramal "$RAMAL"
done

# Processar includes de espelhos
grep -oP '(?<=#include\\s)ramais/espelhos/espelhos\\d+\\.conf' "$PJSIP_CONF" | while read -r INCLUDE; do
  BASE=$(basename "$INCLUDE" .conf | grep -oP '\\d+')
  gerar_espelhos "$BASE"
done
