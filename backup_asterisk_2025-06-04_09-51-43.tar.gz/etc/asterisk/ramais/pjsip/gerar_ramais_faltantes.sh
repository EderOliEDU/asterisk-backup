#!/bin/bash

PJSIP_CONF="/etc/asterisk/pjsip.conf"
RAMAIS_DIR="/etc/asterisk/ramais"

# Verifica se o diretório de ramais existe
if [ ! -d "$RAMAIS_DIR" ]; then
    echo "Diretório $RAMAIS_DIR não encontrado. Criando..."
    mkdir -p "$RAMAIS_DIR"
fi

# Lê todas as linhas que contenham includes de ramais
grep -oP '(?<=#include\s)ramais/ramal\d+\.conf' "$PJSIP_CONF" | while read -r include_path; do
    ramal_file="$RAMAIS_DIR/$(basename "$include_path")"

    # Extrai o número do ramal do nome do arquivo
    ramal_num=$(echo "$ramal_file" | grep -oP '\d+')

    # Se o arquivo ainda não existe, cria com o conteúdo padrão
    if [ ! -f "$ramal_file" ]; then
        echo "Criando $ramal_file para ramal $ramal_num..."

        cat <<EOF > "$ramal_file"
; ======================================
; Configuracao do Ramal e Tronco - $ramal_num
; ======================================

[$ramal_num]
type=endpoint
transport=transport-tls
context=chamadas-realizadas
disallow=all
allow=g722,ulaw,alaw
auth=auth$ramal_num
aors=$ramal_num
direct_media=no

[auth$ramal_num]
type=auth
auth_type=userpass
username=$ramal_num
password=senha$ramal_num

[$ramal_num]
type=aor
max_contacts=1

; ======================================
; Tronco vinculado ao Ramal $ramal_num (Oi)
; ======================================

[oi-$ramal_num]
type=endpoint
transport=transport-tls
aors=oi-$ramal_num-aor
context=entrada-oi
disallow=all
allow=alaw,ulaw
force_rport=yes
outbound_auth=oi-$ramal_num-auth
outbound_proxy=sip:200.97.69.122:5061
from_domain=200.97.69.122
from_user=6634100$(printf "%03d" $ramal_num)
trust_id_inbound=yes
trust_id_outbound=yes
send_pai=yes
send_rpid=yes
sdp_session=pjmedia

[oi-$ramal_num-aor]
type=aor
contact=sip:6634100$(printf "%03d" $ramal_num)@200.97.69.122:5061
max_contacts=1
qualify_frequency=15

[oi-$ramal_num-auth]
type=auth
auth_type=userpass
username=6634100$(printf "%03d" $ramal_num)
password=SENHA_DO_NUMERO_AQUI

[oi-$ramal_num-identify]
type=identify
endpoint=oi-$ramal_num
match=200.97.69.122
EOF
    else
        echo "Arquivo $ramal_file já existe. Ignorando."
    fi
done
