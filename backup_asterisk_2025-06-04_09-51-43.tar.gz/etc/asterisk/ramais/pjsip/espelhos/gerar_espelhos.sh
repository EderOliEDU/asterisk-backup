#!/bin/bash

PJSIP_CONF="/etc/asterisk/pjsip.conf"
ESPELHO_DIR="/etc/asterisk/ramais/espelhos"

# Verifica se o diretório existe
if [ ! -d "$ESPELHO_DIR" ]; then
    echo "Criando diretório $ESPELHO_DIR..."
    mkdir -p "$ESPELHO_DIR"
fi

# Procura includes de espelhos
grep -oP '(?<=#include\\s)ramais/espelhos/espelhos\\d+0\\.conf' "$PJSIP_CONF" | while read -r include_path; do
    arquivo_espelho="$ESPELHO_DIR/$(basename "$include_path")"
    base=$(echo "$arquivo_espelho" | grep -oP '\\d+')

    if [ ! -f "$arquivo_espelho" ]; then
        echo "Arquivo $arquivo_espelho não encontrado."
        echo -n "Quantos espelhos deseja criar para o ramal $base? "
        read QTD

        echo "Criando espelhos no arquivo: $arquivo_espelho"
        echo "; Ramais espelhos do ramal $base" > "$arquivo_espelho"

        for i in $(seq 1 $QTD); do
            prefix="${i}${base}"
            cat <<EOF >> "$arquivo_espelho"

[$prefix]
type=endpoint
context=chamadas-realizadas
disallow=all
allow=g722,ulaw,alaw
auth=auth$prefix
aors=$base
direct_media=no

[auth$prefix]
type=auth
auth_type=userpass
username=$prefix
password=senha$prefix

[$prefix]
type=aor
max_contacts=1
EOF
        done

        echo "Arquivo $arquivo_espelho criado com $QTD espelhos."
    else
        echo "Arquivo $arquivo_espelho já existe. Ignorando."
    fi
done
