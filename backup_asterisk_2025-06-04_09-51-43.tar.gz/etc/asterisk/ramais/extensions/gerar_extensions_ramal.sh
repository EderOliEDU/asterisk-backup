#!/bin/bash

EXTENSIONS_CONF="/etc/asterisk/extensions.conf"
BASE_DIR="/etc/asterisk"
EXT_DIR="$BASE_DIR/ramais/extensions"

# Garante que o diretório existe
mkdir -p "$EXT_DIR"

echo "Verificando includes no $EXTENSIONS_CONF..."

# Detecta includes que apontem para ramal6XX.conf (relativo ou absoluto)
grep -oP '#include\s+.*ramal6\d{2}\.conf' "$EXTENSIONS_CONF" | while read -r line; do
    INCLUDE_PATH=$(echo "$line" | awk '{print $2}')

    # Se for relativo, transforma em absoluto
    if [[ "$INCLUDE_PATH" != /* ]]; then
        INCLUDE_PATH="$BASE_DIR/$INCLUDE_PATH"
    fi

    if [ ! -f "$INCLUDE_PATH" ]; then
        echo "Arquivo não encontrado: $INCLUDE_PATH"
        echo "Criando arquivo padrão..."

        cat <<EOF > "$INCLUDE_PATH"
[discagem-externa]
exten => _X.,1,NoOp(Discagem externa de \${CALLERID(num)} para \${EXTEN})
 same => n,GotoIf(\$[\${PJSIP_HEADER(read,Call-ID)} = ""]?fallback,s,1)
 same => n,Set(NUMRAMAL=\${CALLERID(num)})
 same => n,ExecIf(\$["\${NUMRAMAL:0:1}" = "1"]?Set(BASE=\${NUMRAMAL:1}))
 same => n,ExecIf(\$["\${NUMRAMAL:0:1}" != "1"]?Set(BASE=\${NUMRAMAL}))
 same => n,Set(CID=6634100\${BASE})
 same => n,NoOp(Usando bina \${CID} e tronco oi-\${BASE})
 same => n,Set(CALLERID(num)=\${CID})
 same => n,Set(PJSIP_HEADER(add,P-Asserted-Identity)="<sip:\${CID}@200.97.69.122>")
 same => n,Dial(PJSIP/\${EXTEN}@oi-\${BASE})
 same => n,Hangup()

[fallback]
exten => s,1,NoOp(Ramal não identificado, forçando CID 6634100600)
 same => n,Set(CALLERID(num)=6634100600)
 same => n,Dial(PJSIP/\${EXTEN}@oi-tronco)
 same => n,Hangup()
EOF

        echo "Arquivo criado: $INCLUDE_PATH"
    else
        echo "Arquivo já existe: $INCLUDE_PATH"
    fi
done
